# bot.py

import os
import discord
from discord.ext import commands

intents = discord.Intents.default()
intents.message_content = True
# (음성 관련 intent는 별도로 켜둘 것)

bot = commands.Bot(
    command_prefix="!",
    intents=intents
)

# Cog 로딩
@bot.event
async def setup_hook():
    # cogs 디렉토리 내부 파일을 모두 로드
    for filename in os.listdir("./cogs"):
        if filename.endswith(".py"):
            try:
                await bot.load_extension(f"cogs.{filename[:-3]}")
                print(f"Loaded cog: cogs.{filename[:-3]}")
            except Exception as e:
                print(f"Failed to load cogs.{filename[:-3]}: {e}")

# 봇 준비 완료
@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")

TOKEN = os.getenv("MTM3OTM4MDYzODk3NjcwNDUyMg.GkoHUg.jL1oZqFDu52v441YJJy2mOK9qPaWq_J-8ssX3E") or "MTM3OTM4MDYzODk3NjcwNDUyMg.GkoHUg.jL1oZqFDu52v441YJJy2mOK9qPaWq_J-8ssX3E"
bot.run(TOKEN)
