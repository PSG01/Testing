# cogs/music.py

import asyncio
import discord
from discord.ext import commands
from discord import Embed, Colour
from discord import app_commands
from discord.ui import View, Button

from utils.ytdl import ytdl, YTDLSource  # 위에서 작성한 utils/ytdl.py를 사용

# ──────────────────────────────────────────────────────────────────────────────
# 음악 재생 컨트롤 뷰 (Skip, Pause, Resume 버튼)
# ──────────────────────────────────────────────────────────────────────────────
class PlaybackControlView(View):
    def __init__(self, cog: "Music", guild_id: int):
        super().__init__(timeout=None)
        self.cog = cog
        self.guild_id = guild_id

    @discord.ui.button(label="⏭️ Skip", style=discord.ButtonStyle.primary, custom_id="playback_skip")
    async def skip_button(self, interaction: discord.Interaction, button: Button):
        vc = interaction.guild.voice_client
        if vc and vc.is_playing():
            vc.stop()
            # _after_song에서 다음곡 재생 및 embed 갱신
            await interaction.response.send_message("⏭️ 스킵 요청을 받았습니다. 다음 곡으로 넘어갑니다.", ephemeral=True)
        else:
            await interaction.response.send_message("🚫 현재 재생 중인 곡이 없습니다.", ephemeral=True)

    @discord.ui.button(label="⏸️ Pause", style=discord.ButtonStyle.secondary, custom_id="playback_pause")
    async def pause_button(self, interaction: discord.Interaction, button: Button):
        vc = interaction.guild.voice_client
        if vc and vc.is_playing():
            vc.pause()
            await interaction.response.send_message("⏸️ 재생을 일시정지했습니다.", ephemeral=True)
        else:
            await interaction.response.send_message("🚫 현재 재생 중인 곡이 없습니다.", ephemeral=True)

    @discord.ui.button(label="▶️ Resume", style=discord.ButtonStyle.secondary, custom_id="playback_resume")
    async def resume_button(self, interaction: discord.Interaction, button: Button):
        vc = interaction.guild.voice_client
        if vc and vc.is_paused():
            vc.resume()
            await interaction.response.send_message("▶️ 재생을 재개했습니다.", ephemeral=True)
        else:
            await interaction.response.send_message("🚫 일시정지된 곡이 없습니다.", ephemeral=True)


# ──────────────────────────────────────────────────────────────────────────────
# 큐 보기(embed) 페이지네이션 뷰 (이전/다음 버튼)
# ──────────────────────────────────────────────────────────────────────────────
class QueueView(View):
    def __init__(self, cog: "Music", guild_id: int, page: int):
        super().__init__(timeout=None)
        self.cog = cog
        self.guild_id = guild_id
        self.page = page  # 0-based index

    @discord.ui.button(label="◀ 이전", style=discord.ButtonStyle.secondary, custom_id="queue_prev")
    async def prev_page(self, interaction: discord.Interaction, button: Button):
        if self.page > 0:
            self.page -= 1
            embed = await self.cog.build_queue_embed(self.guild_id, self.page)
            await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="다음 ▶", style=discord.ButtonStyle.secondary, custom_id="queue_next")
    async def next_page(self, interaction: discord.Interaction, button: Button):
        total_items = len(self.cog.guild_queues.get(self.guild_id, []))
        total_pages = (total_items - 1) // 10
        if self.page < total_pages:
            self.page += 1
            embed = await self.cog.build_queue_embed(self.guild_id, self.page)
            await interaction.response.edit_message(embed=embed, view=self)


class Music(commands.Cog):
    """
    • /재생, /스킵, /일시정지, /재개, /볼륨, /큐 등 음악 제어
    • 검색어 입력 시 YouTube에서 상위 5개 결과를 보여주고,
      버튼을 클릭하면 해당 곡을 재생함
    • URL 입력 시 해당 비디오/재생목록을 재생하거나/큐에 추가
    """

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # guild_id별 대기열: { guild_id: [url1, url2, ...] }
        self.guild_queues: dict[int, list[str]] = {}
        # 현재 재생 중인 곡 정보: { guild_id: {"info": info_dict, "message_id": int} }
        self.now_playing: dict[int, dict] = {}
        # message_id별 검색 결과 캐싱: { message_id: [entry_dict, ...] }
        self.search_results: dict[int, list[dict]] = {}

    # ──────────────────────────────────────────────────────────────────────────
    # 안전하게 메시지/임베드를 전송하기 위한 헬퍼
    # ──────────────────────────────────────────────────────────────────────────
    async def safe_send(self, ctx_or_interaction, *args, **kwargs):
        """
        • ctx_or_interaction이 commands.Context이면 ctx.send()
        • 아니면 Interaction이므로 response.send_message() 또는 followup.send()
        """
        if isinstance(ctx_or_interaction, commands.Context):
            return await ctx_or_interaction.send(*args, **kwargs)
        else:
            interaction: discord.Interaction = ctx_or_interaction
            try:
                if not interaction.response.is_done():
                    return await interaction.response.send_message(*args, **kwargs)
                else:
                    return await interaction.followup.send(*args, **kwargs)
            except discord.NotFound:
                # 이미 응답이 완료된 경우
                return await interaction.followup.send(*args, **kwargs)

    # ──────────────────────────────────────────────────────────────────────────
    # 1) 재생 PREFIX (예: !재생 <검색어 or URL>)
    # ──────────────────────────────────────────────────────────────────────────
    @commands.command(name="재생", help="곡 재생: !재생 <검색어 or YouTube URL>")
    async def play_prefix(self, ctx: commands.Context, *, query: str):
        await self._play(ctx, ctx, query)

    # ──────────────────────────────────────────────────────────────────────────
    # 2) 재생 SLASH (예: /재생 <검색어 or URL>)
    # ──────────────────────────────────────────────────────────────────────────
    @app_commands.command(name="재생", description="곡 재생: /재생 <검색어 or YouTube URL>")
    @app_commands.describe(query="검색어 또는 YouTube URL")
    async def play_slash(self, interaction: discord.Interaction, query: str):
        await interaction.response.defer()
        await self._play(interaction, interaction, query)

    # ──────────────────────────────────────────────────────────────────────────
    # 3) 스킵 PREFIX (예: !스킵)
    # ──────────────────────────────────────────────────────────────────────────
    @commands.command(name="스킵", help="현재 재생 중인 곡을 스킵합니다.")
    async def skip_prefix(self, ctx: commands.Context):
        vc = ctx.guild.voice_client
        if vc and vc.is_playing():
            vc.stop()

    # ──────────────────────────────────────────────────────────────────────────
    # 4) 일시정지 PREFIX (예: !일시정지)
    # ──────────────────────────────────────────────────────────────────────────
    @commands.command(name="일시정지", help="현재 재생 중인 곡을 일시정지합니다.")
    async def pause_prefix(self, ctx: commands.Context):
        vc = ctx.guild.voice_client
        if vc and vc.is_playing():
            vc.pause()

    # ──────────────────────────────────────────────────────────────────────────
    # 5) 재개 PREFIX (예: !재개)
    # ──────────────────────────────────────────────────────────────────────────
    @commands.command(name="재개", help="일시정지된 곡을 재개합니다.")
    async def resume_prefix(self, ctx: commands.Context):
        vc = ctx.guild.voice_client
        if vc and vc.is_paused():
            vc.resume()

    # ──────────────────────────────────────────────────────────────────────────
    # 6) 볼륨 PREFIX (예: !볼륨 <0~200>)
    # ──────────────────────────────────────────────────────────────────────────
    @commands.command(name="볼륨", help="볼륨 변경: !볼륨 <0~200>")
    async def volume_prefix(self, ctx: commands.Context, vol: int):
        vc = ctx.guild.voice_client
        if vc and vc.source:
            vc.source.volume = max(0.0, min(vol / 100, 2.0))
            await ctx.send(f"🔊 볼륨을 {vol}% 로 설정했습니다.", delete_after=5)

    # ──────────────────────────────────────────────────────────────────────────
    # 7) 큐 보기 PREFIX (예: !큐)
    #    한 페이지에 10개씩, 제목+링크 형태로 보여주고 버튼으로 페이지 전환
    # ──────────────────────────────────────────────────────────────────────────
    @commands.command(name="큐", help="현재 대기열을 보여줍니다.")
    async def queue_prefix(self, ctx: commands.Context):
        queue = self.guild_queues.get(ctx.guild.id, [])
        if not queue:
            await ctx.send("📭 대기열이 비어 있습니다.")
            return

        embed = await self.build_queue_embed(ctx.guild.id, page=0)
        view = QueueView(self, ctx.guild.id, page=0)
        await ctx.send(embed=embed, view=view)

    # ──────────────────────────────────────────────────────────────────────────
    # 큐 Embed 생성 (페이지는 0-based index; 10개씩)
    # ──────────────────────────────────────────────────────────────────────────
    async def build_queue_embed(self, guild_id: int, page: int) -> Embed:
        queue = self.guild_queues.get(guild_id, [])
        total = len(queue)
        per_page = 10
        total_pages = (total - 1) // per_page + 1

        start = page * per_page
        end = min(start + per_page, total)
        current_slice = queue[start:end]

        embed = Embed(
            title=f"📋 대기열 (페이지 {page+1}/{total_pages})",
            color=Colour.blue()
        )

        if not current_slice:
            embed.description = "❗ 해당 페이지에 표시할 곡이 없습니다."
            return embed

        lines = []
        # 각 URL에서 제목을 불러와 링크 형태로 표시
        loop = self.bot.loop
        for idx, url in enumerate(current_slice, start=start + 1):
            try:
                info = await loop.run_in_executor(None, lambda: ytdl.extract_info(url, download=False))
                title = info.get("title", "제목 없음")
            except Exception:
                title = "제목 불러오기 실패"
            lines.append(f"**{idx}.** [{title}]({url})")

        embed.description = "\n".join(lines)
        return embed

    # ──────────────────────────────────────────────────────────────────────────
    # 내부 재생 로직: 검색 or URL 모두 처리
    # ──────────────────────────────────────────────────────────────────────────
    async def _play(self, ctx_obj, src_ctx, query: str):
        """
        • ctx_obj: commands.Context 또는 discord.Interaction (음성 연결+다음곡용)
        • src_ctx: Embeded/메시지 전송 시도용 (Context or Interaction)
        • query: 검색어(텍스트) or YouTube URL
        """
        # Interaction인지 Context인지 판별하여 author, guild 추출
        if isinstance(ctx_obj, commands.Context):
            author = ctx_obj.author
            guild = ctx_obj.guild
        else:
            author = ctx_obj.user
            guild = ctx_obj.guild

        # 1) 유저가 음성 채널에 들어있는지 확인
        if not author.voice or not author.voice.channel:
            await self.safe_send(src_ctx, "🚫 먼저 음성 채널에 들어가세요.", delete_after=5)
            return
        voice_channel = author.voice.channel

        # 2) VoiceClient 준비
        vc = guild.voice_client
        if not vc:
            try:
                vc = await voice_channel.connect()
            except discord.ClientException:
                vc = guild.voice_client

        guild_id = guild.id
        is_url = query.startswith("http://") or query.startswith("https://")

        # ────────────────────────────────────────────────────────────────────────
        # 3) 검색어(텍스트) 처리: ytsearch5: 상위 5개 결과
        # ────────────────────────────────────────────────────────────────────────
        if not is_url:
            search_term = query.strip()
            search_query = f"ytsearch5:{search_term}"
            loop = self.bot.loop
            try:
                data = await loop.run_in_executor(None, lambda: ytdl.extract_info(search_query, download=False))
            except Exception:
                await self.safe_send(src_ctx, "🚫 검색 중 오류가 발생했습니다.", delete_after=10)
                return

            if not data or "entries" not in data:
                await self.safe_send(src_ctx, "🚫 검색 결과가 없습니다.", delete_after=5)
                return

            entries = [e for e in data["entries"] if e]
            if not entries:
                await self.safe_send(src_ctx, "🚫 검색 결과가 없습니다.", delete_after=5)
                return

            top_entries = entries[:5]

            # 검색 결과 임베드 작성
            embed = Embed(
                title=f"🔍 \"{search_term}\" 검색 결과 (상위 {len(top_entries)}개)",
                description="\n".join(
                    f"**{idx+1}.** {entry.get('title', '제목 없음')}"
                    for idx, entry in enumerate(top_entries)
                ),
                color=Colour.magenta()
            )
            embed.set_footer(text="버튼을 눌러 재생할 곡을 선택하세요.")
            first_thumb = top_entries[0].get("thumbnail")
            if first_thumb:
                embed.set_thumbnail(url=first_thumb)

            view = self.SearchSelectView(self, guild_id, top_entries)
            message = await self.safe_send(src_or_interaction=src_ctx, embed=embed, view=view)

            # 상호작용(Interaction)인 경우, 메시지 아이디를 캐싱
            if isinstance(message, discord.Message):
                self.search_results[message.id] = top_entries
            return

        # ────────────────────────────────────────────────────────────────────────
        # 4) URL 처리: 단일 비디오 or 재생목록
        # ────────────────────────────────────────────────────────────────────────
        loop = self.bot.loop
        try:
            info_all = await loop.run_in_executor(None, lambda: ytdl.extract_info(query, download=False))
        except Exception:
            await self.safe_send(src_ctx, "🚫 URL 정보를 가져오는 중 오류가 발생했습니다.", delete_after=10)
            return

        if not info_all:
            await self.safe_send(src_ctx, "🚫 해당 URL에서 정보를 가져오지 못했습니다.", delete_after=5)
            return

        # -- 재생목록인 경우: entries 리스트 → URL만 추출해서 큐에 추가
        if "entries" in info_all and isinstance(info_all["entries"], list):
            entries = info_all["entries"]
            added = 0
            for entry in entries:
                if not entry:
                    continue
                video_url = entry.get("webpage_url") or entry.get("url")
                if not video_url:
                    vid = entry.get("id")
                    if vid:
                        video_url = f"https://www.youtube.com/watch?v={vid}"
                    else:
                        continue

                # 재생 가능 여부 확인 (private/deleted 영상 제외)
                try:
                    info_check = await loop.run_in_executor(None, lambda: ytdl.extract_info(video_url, download=False))
                except Exception:
                    continue
                if not info_check or info_check.get("is_private") or info_check.get("is_live"):
                    continue

                self.guild_queues.setdefault(guild_id, []).append(video_url)
                added += 1

            if added == 0:
                await self.safe_send(src_ctx, "🚫 재생 가능한 영상이 없습니다.", delete_after=5)
                return

            await self.safe_send(src_ctx, f"🌐 **{added}곡**을 대기열에 추가했습니다.")
            # 현재 아무 곡도 재생 중이 아니라면 즉시 첫 곡 재생
            if not (vc and vc.is_playing()) and self.guild_queues.get(guild_id):
                next_url = self.guild_queues[guild_id].pop(0)
                await self._play(ctx_obj, src_ctx, next_url)
            return

        # -- 단일 비디오: 즉시 재생 --
        try:
            player: YTDLSource = await YTDLSource.from_url(
                query,
                loop=self.bot.loop,
                stream=True
            )
        except Exception:
            await self.safe_send(src_ctx, "🚫 곡 로드에 실패했습니다. URL을 확인해주세요.", delete_after=5)
            return

        # 이미 재생 중이라면 → 큐에 추가 + “큐에 등록됨” 임베드
        if vc and vc.is_playing():
            self.guild_queues.setdefault(guild_id, []).append(query)
            await self.send_now_playing_embed(
                ctx_or_interaction=src_ctx,
                guild_id=guild_id,
                info=player.data,
                queued=True
            )
            return

        # 바로 재생
        def _after_play(error):
            fut = asyncio.run_coroutine_threadsafe(self._after_song(ctx_obj), self.bot.loop)
            try:
                fut.result()
            except Exception:
                pass

        try:
            vc.play(player, after=_after_play)
        except Exception:
            await self.safe_send(src_ctx, "🚫 재생 중 오류가 발생했습니다.", delete_after=5)
            await asyncio.sleep(1)
            return await self._after_song(ctx_obj)

        # 재생 정보 업데이트 + embed 전송
        self.now_playing[guild_id] = {"info": player.data, "message_id": None}
        await self.send_now_playing_embed(
            ctx_or_interaction=src_ctx,
            guild_id=guild_id,
            info=player.data,
            queued=False
        )

    # ──────────────────────────────────────────────────────────────────────────
    # 5) 검색 결과 선택용 View (버튼 1~5)
    # ──────────────────────────────────────────────────────────────────────────
    class SearchSelectView(View):
        def __init__(self, cog: "Music", guild_id: int, entries: list[dict]):
            super().__init__(timeout=None)
            self.cog = cog
            self.guild_id = guild_id
            self.entries = entries

        @discord.ui.button(label="1", style=discord.ButtonStyle.primary, custom_id="select_1")
        async def select_1(self, interaction: discord.Interaction, button: Button):
            await self._select_and_play(interaction, 0)

        @discord.ui.button(label="2", style=discord.ButtonStyle.primary, custom_id="select_2")
        async def select_2(self, interaction: discord.Interaction, button: Button):
            await self._select_and_play(interaction, 1)

        @discord.ui.button(label="3", style=discord.ButtonStyle.primary, custom_id="select_3")
        async def select_3(self, interaction: discord.Interaction, button: Button):
            await self._select_and_play(interaction, 2)

        @discord.ui.button(label="4", style=discord.ButtonStyle.primary, custom_id="select_4")
        async def select_4(self, interaction: discord.Interaction, button: Button):
            await self._select_and_play(interaction, 3)

        @discord.ui.button(label="5", style=discord.ButtonStyle.primary, custom_id="select_5")
        async def select_5(self, interaction: discord.Interaction, button: Button):
            await self._select_and_play(interaction, 4)

        async def _select_and_play(self, interaction: discord.Interaction, index: int):
            message_id = interaction.message.id
            entries = self.cog.search_results.get(message_id)
            if not entries or index >= len(entries):
                await interaction.response.send_message("🚫 선택할 수 없습니다.", ephemeral=True)
                return

            entry = entries[index]
            video_url = entry.get("webpage_url") or entry.get("url")
            if not video_url:
                await interaction.response.send_message("🚫 해당 곡 URL을 가져올 수 없습니다.", ephemeral=True)
                return

            # 버튼 비활성화
            for child in self.children:
                child.disabled = True

            selected_title = entry.get("title", "제목 없음")
            embed = Embed(
                title="▶️ 선택된 곡",
                description=f"**{selected_title}** 을(를) 재생합니다.",
                color=Colour.purple()
            )
            thumb = entry.get("thumbnail")
            if thumb:
                embed.set_thumbnail(url=thumb)

            await interaction.response.edit_message(embed=embed, view=self)
            # 선택된 URL로 재생 호출
            await self.cog._play(interaction, interaction, video_url)

    # ──────────────────────────────────────────────────────────────────────────
    # 6) 곡 재생 완료 후 처리 (이전 embed 삭제 → 다음 곡 or 연결 해제)
    # ──────────────────────────────────────────────────────────────────────────
    async def _after_song(self, ctx_obj):
        """
        • 재생이 끝났을 때 호출됨
        • 이전 embed 삭제 → 큐에서 다음 곡 꺼내 재생하거나 → 음성 연결 해제
        """
        if isinstance(ctx_obj, commands.Context):
            guild_id = ctx_obj.guild.id
            vc = ctx_obj.guild.voice_client
            channel = ctx_obj.channel
        else:
            guild_id = ctx_obj.guild.id
            vc = ctx_obj.guild.voice_client
            channel = ctx_obj.channel

        # 1) 이전 임베드 삭제
        previous_msg_id = self.now_playing.get(guild_id, {}).get("message_id")
        if previous_msg_id:
            try:
                old_msg = await channel.fetch_message(previous_msg_id)
                await old_msg.delete()
            except:
                pass

        # 2) 큐에서 다음 URL 꺼내기
        queue = self.guild_queues.get(guild_id, [])
        if queue:
            next_url = queue.pop(0)
            await self._play(ctx_obj, ctx_obj, next_url)
        else:
            # 큐가 비었으면 음성 연결 해제
            if vc and vc.is_connected():
                await vc.disconnect()
            self.now_playing.pop(guild_id, None)

    # ──────────────────────────────────────────────────────────────────────────
    # 7) 재생/큐 등록 임베드 전송:
    #    • 중앙에 큰 썸네일, 우측 상단에 작은 썸네일
    #    • 이전 임베드 메시지 삭제 → 최신 임베드 전송
    # ──────────────────────────────────────────────────────────────────────────
    async def send_now_playing_embed(
        self,
        ctx_or_interaction,
        guild_id: int,
        info: dict,
        *,
        queued: bool = False
    ):
        """
        • queued=True → 큐 등록 임베드
        • queued=False → 지금 재생 중 임베드
        """
        video_id = info.get("id")
        thumbnail = info.get("thumbnail") or (f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg" if video_id else None)

        # 재생 길이 문자열
        duration_sec = info.get("duration") or 0
        if isinstance(duration_sec, (int, float)) and duration_sec > 0:
            minutes, seconds = divmod(int(duration_sec), 60)
            duration_str = f"{minutes}분 {seconds}초"
        else:
            duration_str = "알 수 없음"

        title = info.get("title", "알 수 없는 곡")

        if queued:
            embed = Embed(
                title="🎵 큐에 등록됨",
                description=f"**{title}** 을(를) 대기열에 추가했습니다.",
                color=Colour.orange()
            )
        else:
            embed = Embed(
                title="🎶 지금 재생 중",
                description=f"**{title}**",
                color=Colour.purple()
            )

        # 중앙 큰 썸네일 + 우측 상단 작은 썸네일
        if thumbnail:
            embed.set_image(url=thumbnail)
            embed.set_thumbnail(url=thumbnail)

        embed.add_field(name="⏱ 길이", value=duration_str, inline=True)

        # 요청자 표시
        requester = None
        if hasattr(ctx_or_interaction, "user"):
            requester = ctx_or_interaction.user
        elif hasattr(ctx_or_interaction, "author"):
            requester = ctx_or_interaction.author

        if requester:
            embed.set_footer(text=f"Requested by {requester.display_name}", icon_url=requester.avatar.url)

        # 재생 컨트롤 버튼 뷰
        view = PlaybackControlView(self, guild_id)

        # 1) 이전 임베드 메시지 삭제
        prev_msg_id = self.now_playing.get(guild_id, {}).get("message_id")
        if prev_msg_id:
            try:
                if isinstance(ctx_or_interaction, commands.Context):
                    channel = ctx_or_interaction.channel
                else:
                    channel = ctx_or_interaction.channel
                old_msg = await channel.fetch_message(prev_msg_id)
                await old_msg.delete()
            except:
                pass

        # 2) 새 임베드 전송
        sent = await self.safe_send(ctx_or_interaction, embed=embed, view=view)

        # 3) 실제 메시지 ID 가져와서 저장
        if isinstance(sent, discord.Message):
            message_id = sent.id
        else:
            orig = await sent.original_response()
            message_id = orig.id

        self.now_playing[guild_id] = {"info": info, "message_id": message_id}


async def setup(bot: commands.Bot):
    await bot.add_cog(Music(bot))
